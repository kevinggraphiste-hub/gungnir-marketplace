# Smoke test marketplace

Workflow de test pour valider le flow Marketplace → Soumettre du Gungnir v4.4+.

Fait : fetch `example.com` → résume en 3 phrases via le LLM actif de l'user.

**À supprimer du marketplace après test** (clic révoquer côté admin Settings).
